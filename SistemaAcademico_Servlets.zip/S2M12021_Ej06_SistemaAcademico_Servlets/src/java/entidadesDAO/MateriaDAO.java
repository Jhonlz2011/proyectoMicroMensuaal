/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidadesDAO;

import entidades.Materia;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import librerias.SisParSis;

/**
 *
 * @author admin
 */
public class MateriaDAO {
    
    private SisParSis objParSis;
    private Connection con;
    private Statement stm;
    private ResultSet rst;
    private String strSQL;
    
    public MateriaDAO()
    {
        objParSis=new SisParSis();
    }
    
    public List<Materia> getListadoMaterias()
    {
        List<Materia> objLisMat=new ArrayList<Materia>();
        try
        {
            //Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5433/dbestudiantes", "postgres", "ClavePostgreSQL2017");
            con=DriverManager.getConnection(objParSis.getStringConexion(), objParSis.getUsuarioConexion(), objParSis.getClaveConexion());
            if (con!=null)
            {
                stm=con.createStatement();
                strSQL=" SELECT co_mat, tx_nom, st_reg";
                strSQL+=" FROM tbm_materias";
                //strSQL+=" WHERE st_reg='A'";
                strSQL+=" ORDER BY co_mat";
                rst=stm.executeQuery(strSQL);
                while (rst.next())
                {
                    Materia objMat=new Materia();
                    objMat.setCodigo(rst.getInt("co_mat"));
                  
                    objMat.setNombre(rst.getString("tx_nom"));
                    objMat.setEstadoRegistro(rst.getString("st_reg"));
                  
                    objLisMat.add(objMat);
                }
                rst.close();
                stm.close();
                con.close();
            }
        }
        catch (java.sql.SQLException e)
        {
            objLisMat=null;
            System.out.println("Excepción: " + e.toString());
        }
        catch (Exception e)
        {
            objLisMat=null;
            System.out.println("Excepción: " + e.toString());
        }
        return objLisMat;
    }
}
